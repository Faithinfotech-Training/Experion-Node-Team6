function ManagerLanding() {
    var head = {
        padding: 20,
        background: 'burlywood',
        fontSize: 20,
        padding: 20,
        margin: 20


    }
    return (
        <>
            <div style={head}>
                <h1>Welcome Manager</h1>

            </div>
        </>
    )
}
export default ManagerLanding;
