function Home() {
    var head = {
        padding: 20,
        background: 'burlywood',
        fontSize: 20,
        padding: 20,
        margin: 20


    }
    return (
        <>
            <div style={head}>
                <h1>Explore More ...</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate exercitationem fuga, omnis molestiae ratione
                    libero quod eaque voluptas quibusdam eum temporibus nihil est porro expedita quas atque quis soluta debitis.
                    Consequuntur neque ad sit aspernatur quasi laudantium. Facilis quod fuga itaque deleniti ut ducimus beatae ea
                    cupiditate odit at quaerat dicta quasi, voluptate nemo tenetur rem soluta voluptas corporis dolorum nulla earum
                    expedita aliquid necessitatibus repellendus? Delectus voluptate aut eos nesciunt soluta, odit eveniet id cumque est
                    repellendus explicabo minima ipsum in ad voluptatem fugit. Ipsam beatae sapiente quae quaerat nesciunt eum
                    consectetur dolores, fugit deserunt nisi amet eius nam deleniti impedit alias voluptatem quisquam laborum iusto
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore repellendus cupiditate doloremque architecto vero, aut suscipit eius repudiandae est incidunt saepe alias. Officia quasi, qui doloremque ipsam sunt ducimus soluta veritatis vitae expedita in rem molestias, animi ipsa eum minima non repellendus blanditiis explicabo aliquid at dolore esse quae porro! Atque ut assumenda nam distinctio magnam dicta voluptates veniam, quaerat eos a ipsa natus. Doloribus, nobis sed! Qui cupiditate, commodi aut beatae eum ea ipsam quisquam non sapiente recusandae dolorem voluptatum quos voluptates aspernatur quia ut vero impedit minus? Vero, blanditiis iusto rem asperiores aperiam sit quae enim necessitatibus in quibusdam consequuntur modi. Sunt et veritatis labore quis beatae perspiciatis asperiores, odio id, cupiditate incidunt praesentium esse dolor accusantium eveniet repellendus quisquam odit alias consequuntur nesciunt iure dolores deserunt. Dolorum ipsum nobis praesentium quam repellat aperiam deserunt ratione iste, commodi molestiae dignissimos laudantium facere deleniti accusamus dicta excepturi accusantium nulla.
                    doloribus. Labore vero aperiam sit itaque. Odit molestiae, harum eius assumenda molestias qui?</p>
            </div>
        </>
    )
}
export default Home;
