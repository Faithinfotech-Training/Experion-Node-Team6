
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link }
  from "react-router-dom";
import About from "./CourseEnquiry/About";
import ThankYou from "./CourseEnquiry/ThankYou";
import CourseEnquiryForm from "./CourseEnquiry/CourseEnquiryForm";
import CourseEnquiryList from "./CourseEnquiry/CourseEnquiryList";
import CourseEnquiryDetails from "./CourseEnquiry/CourseEnquiryDetails";
import EditCourseEnquiry from "./CourseEnquiry/EditCourseEnquiry";
import AdminLanding from "./CourseEnquiry/AdminLanding";
import Login from "./Login";
import ManagerLanding from "./CourseEnquiry/ManagerLanding";
import './courseStyles.css'
import Home from "./CourseEnquiry/Home";

import CourseApp from "./Course/Course";


import CourseDetails from "./Course/courseDetails";
import CourseEdit from "./Course/courseEdit";
import CourseList from "./Course/courseList";
import CourseAccess from "./Course/courseAccess";
import CreateResource from "./Resources/CreateResource";

import './App.css';
import ViewResources from "./Resources/ViewResources";

const styling={
  marginTop:"0%",
  display:"inline",
  backgroundColor:"blue"
}
const styling1={
  marginTop:"0%",
  
  
}



function App() {
 
  return (
    <MyRouter />
    
  );
}
function MyRouter() {
  return (
    <Router>
      <div className='navbar'>

      <ul>
            <div id="col">
           <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/course">Create Course</Link>
            </li>
           
            <li>
              <Link to="/courselist">View Course</Link>
            </li>
            <li>
              <Link to="/resource/create">Create Resource</Link>
            </li>
            <li>
              <Link to="/resource/view">View Resources</Link>
            </li>
         
        
            </div>
          </ul>
        <div><Link className="Link" to='/'>Home</Link></div>
        <div><Link className="Link" to='/about'>About</Link></div>
        {!localStorage.getItem('mytoken') && <div><Link className="Link" to='/courseenquiry'>Course Enquiry Form</Link></div>}
        {localStorage.getItem('mytoken') && <div><Link className="Link" to="/courseenquirylist">Course Enquiry List</Link></div>}
        {/* <div><Link to ='/courseenquirylist'>View Course Enquiry List </Link></div> */}
        {!localStorage.getItem('mytoken') && <div ><Link className="Link" to="/login">Login</Link></div>}
        {localStorage.getItem('mytoken') && <div><Link className="Link" onClick={() => window.location = '/login'} to="/login">Logout</Link></div>}

        <div></div>

      </div>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/courseenquiry" element={<CourseEnquiryForm />} />
        <Route path="/courseenquirylist" element={<CourseEnquiryList />} />
        <Route path="/courseenquirydetails/:course_enquiryId" element={<CourseEnquiryDetails />} />
        <Route path="/courseenquiryupdate/:course_enquiryId" element={<EditCourseEnquiry />} />
        <Route path="/admin" element={<AdminLanding />} />
        <Route path="/manager" element={<ManagerLanding />} />

        <Route path="/login" element={<Login />} />

        <Route path="/thanks" element={<ThankYou />} />
        <Route path="/courseedit" element={<CourseEdit />}/>
          <Route path="/course" element={<CourseApp />}/>
          <Route path="/courselist" element={<CourseList />}/>
          <Route path="/courseaccess" element={<CourseAccess />}/>
          <Route path="/courseedit/:id" element={<CourseEdit/>}/>
          <Route path="/coursedetails/:id" element={<CourseDetails />}/>
          <Route path="/coursedetails" element={<CourseDetails />}/>
          <Route path="/resource/create" element={<CreateResource />}/>
          <Route path="/resource/view" element={<ViewResources />}/>
      </Routes>

    </Router>);
}

export default App;